'use strict'

//1. 조건문
let num = 24;
if(num%4=== 0){
    console.log('참 입니다.')
}else{
    console.log('거짓 입니다.')
}

//1_1. 조건문 연습
//let soo = prompt('입력')
//if(soo>=90){
//   alert('a')
//}else if(soo>=60){
//   alert('b')
//}else{
//    alert('c')
//}

//2. swith문
// let sw = prompt('입력')
// switch(sw){
//     case 'back-end':
//         console.log('back')
//         break;
//     case 'front-end':
//         console.log('front')
//         break;
//     case 'full-stack':
//         console.log('full')
//         break;
//     default:
//         console.log('쉴패!')
// }