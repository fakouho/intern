'use strict';

/* 1) 숫자 */
let num1 = 1;
let num2 = 1.2;
console.log('정수 : ',num1)
console.log('실수 : ',num2)

/* 2) 문자 */
let str1 ='우석';
let str2 = "우석";
let str3 = `우석`
console.log(str1);
console.log(str2);
console.log(`안녕하세요 ${str3}입니다.`);

/*3)불리언 */
let b = true;
let a = false;

/*3)null,undifined */
const un =null;
let n1 =undefined;

